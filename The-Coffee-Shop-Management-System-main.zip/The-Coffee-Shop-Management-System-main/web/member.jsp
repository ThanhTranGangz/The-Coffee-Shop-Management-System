<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nhà cà phê. — quản lý quán</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        coffee: {
                            bg: '#F6F2E9',       
                            dark: '#2B1B17',     
                            rust: '#A04423',     
                            sand: '#E5DEC9',     
                            light: '#FAF7EE',    
                            milk: '#8E7D6F'      
                        }
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F6F2E9;
            color: #2B1B17;
        }
        .font-serif {
            font-family: 'Playfair Display', serif;
        }
        .font-mono {
            font-family: 'JetBrains Mono', monospace;
        }
        
        .dot-grid-bg {
            background-color: #F6F2E9;
            background-image: radial-gradient(#d3cbb6 1.2px, transparent 1.2px);
            background-size: 24px 24px;
        }
        
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: rgba(43, 27, 23, 0.05);
            border-radius: 99px;
        }
        ::-webkit-scrollbar-thumb {
            background: rgba(160, 68, 35, 0.3);
            border-radius: 99px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: rgba(160, 68, 35, 0.5);
            border-radius: 99px;
        }
    </style>
    <script>
        (function() {
            var role = localStorage.getItem('auth_role') || '';
            var user = localStorage.getItem('auth_user') || '';
            var path = window.location.pathname;
            var page = path.substring(path.lastIndexOf('/') + 1) || 'index.html';

            var customerPages = ['menu.jsp', 'order-status.jsp', 'member.jsp'];
            var waiterPages = ['waitstation.jsp', 'staff-orders.jsp', 'table-qr.jsp', 'order-summary.jsp'];
            var baristaPages = ['kds.jsp'];
            var managerPages = ['dashboard.jsp', 'reports.jsp', 'staff-management.jsp', 'inventory.jsp'];

            if (role && waiterPages.indexOf(page) !== -1 && role !== 'waiter' && role !== 'manager') {
                try { alert('Cảnh báo bảo mật: Bạn không có quyền truy cập khu vực Phục vụ / Wait station!'); } catch(e) { console.warn(e); }
                window.location.href = 'login.jsp';
                return;
            }
            if (role && baristaPages.indexOf(page) !== -1 && role !== 'barista' && role !== 'manager') {
                try { alert('Cảnh báo bảo mật: Bạn không có quyền truy cập khu vực Quầy pha chế (KDS)!'); } catch(e) { console.warn(e); }
                window.location.href = 'login.jsp';
                return;
            }
            if (role && managerPages.indexOf(page) !== -1 && role !== 'manager') {
                try { alert('Cảnh báo bảo mật: Bạn không có quyền truy cập khu vực Bảng điều khiển Quản lý!'); } catch(e) { console.warn(e); }
                window.location.href = 'login.jsp';
                return;
            }

            document.addEventListener("DOMContentLoaded", function() {
                var navContainer = document.querySelector('nav div.hidden.lg\\:flex');
                if (!navContainer) return;

                var navHtml = '';
                if (customerPages.indexOf(page) !== -1 || page === 'index.html' || page === 'login.jsp' || page === 'pin-login.jsp') {
                    if (!role) {
                        navHtml = 
                            '<a href="index.html" class="hover:text-coffee-rust transition-colors ' + (page === 'index.html' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Trang chủ</a>' +
                            '<a href="menu.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'menu.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + ' font-semibold">Khách gọi món</a>' +
                            '<a href="order-status.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'order-status.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Kiểm tra đơn nước</a>' +
                            '<a href="member.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'member.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Khách thành viên</a>';
                    } else if (role === 'waiter') {
                        navHtml = 
                            '<a href="index.html" class="hover:text-coffee-rust transition-colors">Trang chủ</a>' +
                            '<a href="waitstation.jsp" class="hover:text-coffee-rust transition-colors font-semibold">Wait station</a>' +
                            '<a href="staff-orders.jsp" class="hover:text-coffee-rust transition-colors">Danh sách order</a>' +
                            '<a href="table-qr.jsp" class="hover:text-coffee-rust transition-colors">In mã QR bàn</a>';
                    } else if (role === 'barista') {
                        navHtml = 
                            '<a href="index.html" class="hover:text-coffee-rust transition-colors">Trang chủ</a>' +
                            '<a href="kds.jsp" class="hover:text-coffee-rust transition-colors font-semibold">KDS pha chế</a>';
                    } else if (role === 'manager') {
                        navHtml = 
                            '<a href="index.html" class="hover:text-coffee-rust transition-colors">Trang chủ</a>' +
                            '<a href="dashboard.jsp" class="hover:text-coffee-rust transition-colors">Dashboard</a>' +
                            '<a href="reports.jsp" class="hover:text-coffee-rust transition-colors">Doanh số</a>' +
                            '<a href="staff-management.jsp" class="hover:text-coffee-rust transition-colors">Nhân sự</a>' +
                            '<a href="inventory.jsp" class="hover:text-coffee-rust transition-colors">Kho hàng</a>' +
                           '<div class="relative group">' +
                               '<button class="bg-coffee-light hover:bg-coffee-sand/30 text-coffee-dark border border-coffee-sand px-3 py-1 rounded-lg flex items-center gap-1 cursor-pointer">' +
                                   '<span>Thao tác trực</span>' +
                                   '<svg class="w-3 h-3 text-coffee-rust" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>' +
                               '</button>' +
                               '<div class="absolute left-0 mt-1 w-52 bg-white border border-coffee-sand rounded-xl shadow-lg py-1.5 hidden group-hover:block z-50">' +
                                '<a href="inventory.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Kho nguyên liệu</a>' +
                                
                                    '<a href="inventory.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Kho nguyên liệu</a>' +
                                    '<a href="waitstation.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Wait station</a>' +
                                   '<a href="kds.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">KDS pha chế</a>' +
                                   '<a href="staff-orders.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Danh sách order</a>' +
                                   '<a href="table-qr.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">In mã QR bàn</a>' +
                                   '<a href="menu.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Giao diện khách</a>' +
                               '</div>' +
                           '</div>';
                    }
                } else if (role === 'waiter' || waiterPages.indexOf(page) !== -1) {
                    navHtml = 
                        '<a href="index.html" class="hover:text-coffee-rust transition-colors ' + (page === 'index.html' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Trang chủ</a>' +
                        '<a href="waitstation.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'waitstation.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + ' font-semibold">Wait station</a>' +
                        '<a href="staff-orders.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'staff-orders.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Danh sách order</a>' +
                        '<a href="table-qr.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'table-qr.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">In mã QR bàn</a>';
                } else if (role === 'barista' || baristaPages.indexOf(page) !== -1) {
                    navHtml = 
                        '<a href="index.html" class="hover:text-coffee-rust transition-colors ' + (page === 'index.html' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Trang chủ</a>' +
                        '<a href="kds.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'kds.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + ' font-semibold">KDS pha chế</a>';
                } else if (role === 'manager' || managerPages.indexOf(page) !== -1) {
                    navHtml = 
                        '<a href="index.html" class="hover:text-coffee-rust transition-colors ' + (page === 'index.html' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Trang chủ</a>' +
                        '<a href="dashboard.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'dashboard.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + ' font-semibold">Dashboard</a>' +
                        '<a href="reports.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'reports.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Doanh số</a>' +
                        '<a href="staff-management.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'staff-management.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Nhân sự</a>' +
                        '<a href="inventory.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'inventory.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Kho hàng</a>' +
                        '<div class="relative group">' +
                            '<button class="bg-coffee-light hover:bg-coffee-sand/30 text-coffee-dark border border-coffee-sand px-3 py-1 rounded-lg flex items-center gap-1 cursor-pointer">' +
                                '<span>Thao tác trực</span>' +
                                '<svg class="w-3 h-3 text-coffee-rust" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>' +
                            '</button>' +
                            '<div class="absolute left-0 mt-1 w-52 bg-white border border-coffee-sand rounded-xl shadow-lg py-1.5 hidden group-hover:block z-50">' +
                                '<a href="inventory.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Kho nguyên liệu</a>' +
                                
                                    '<a href="inventory.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Kho nguyên liệu</a>' +
                                    '<a href="waitstation.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Wait station</a>' +
                                '<a href="kds.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">KDS pha chế</a>' +
                                '<a href="staff-orders.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Danh sách order</a>' +
                                '<a href="table-qr.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">In mã QR bàn</a>' +
                                '<a href="menu.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Giao diện khách</a>' +
                            '</div>' +
                        '</div>';
                }
                navContainer.innerHTML = navHtml;

                var rightNavArea = document.querySelector('nav div.flex.items-center.gap-3 div.flex.items-center.gap-1\\.5') || document.querySelector('nav div.flex.items-center.gap-3');
                if (rightNavArea && role) {
                    var roleBadge = '';
                    if (role === 'manager') roleBadge = 'Quản lý';
                    else if (role === 'waiter') roleBadge = 'Phục vụ';
                    else if (role === 'barista') roleBadge = 'Pha chế';

                    var badgeHtml = 
                        '<div class="flex items-center gap-2">' +
                            '<div class="bg-coffee-dark text-coffee-bg border border-coffee-rust/30 px-3.5 py-1.5 rounded-xl text-[10px] uppercase font-bold font-mono tracking-wide flex items-center gap-1.5 shadow-xs">' +
                                '<span class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping"></span>' +
                                '<span>' + roleBadge + ': ' + user + '</span>' +
                            '</div>' +
                            '<button onclick="handleLocalLogout()" class="text-xs font-bold px-2 py-1.5 bg-red-50 hover:bg-red-500 hover:text-white border border-red-200 text-red-600 rounded-xl shadow-xs transition-all cursor-pointer">' +
                                'Đăng xuất' +
                            '</button>' +
                        '</div>';

                    var backBtnChild = rightNavArea.querySelector('a[href="index.html"]');
                    if (backBtnChild) {
                        backBtnChild.parentElement.innerHTML = badgeHtml;
                    } else {
                        var existingLogoutBtn = rightNavArea.querySelector('button[onclick="handleLocalLogout()"]');
                        if (!existingLogoutBtn) {
                            var badgeDiv = document.createElement('div');
                            badgeDiv.className = 'flex items-center gap-1.5 ml-2';
                            badgeDiv.innerHTML = badgeHtml;
                            rightNavArea.appendChild(badgeDiv);
                        }
                    }
                }
            });
        })();

        function handleLocalLogout() {
            localStorage.removeItem('auth_role');
            localStorage.removeItem('auth_user');
            alert('Đã đăng xuất tài khoản làm việc POS! Chuyển hướng về cổng portal.');
            window.location.href = 'index.html';
        }
    </script>
    <link rel="stylesheet" href="assets/css/pro-ui.css">
    <script defer src="assets/js/ui-polish.js"></script>
</head>
<body class="min-h-screen flex flex-col dot-grid-bg relative selection:bg-coffee-rust/20 selection:text-coffee-rust">

    <nav class="border-b border-coffee-sand/70 bg-coffee-bg/90 backdrop-blur sticky top-0 z-40 px-6 py-4 transition-all">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            
            <a href="index.html" class="flex items-center gap-2 group">
                <span class="text-2xl font-serif font-extrabold tracking-tight text-coffee-dark select-none">
                    nhà cà phê<span class="text-coffee-rust">.</span>
                </span>
            </a>

            <div class="hidden lg:flex items-center gap-4 text-xs font-medium">
                <a href="index.html" class="hover:text-coffee-rust transition-colors text-coffee-milk">Trang chủ</a>
                <a href="menu.jsp" class="hover:text-coffee-rust transition-colors text-coffee-milk">Khách gọi món</a>
                <a href="order-status.jsp" class="hover:text-coffee-rust transition-colors text-coffee-milk">Kiểm tra đơn nước</a>
                <a href="member.jsp" class="hover:text-coffee-rust transition-colors text-coffee-dark font-bold">Khách thành viên</a>
            </div>

            <div class="flex items-center gap-3">
                
                <div id="connection-status">
                    <div class="bg-amber-50 text-amber-800 border border-amber-200/50 px-3 py-1 rounded-full text-xs flex items-center gap-1.5 font-medium">
                        <span class="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse"></span>
                        <span>Đang kết nối...</span>
                    </div>
                </div>

                <div class="hidden md:flex bg-coffee-light border border-coffee-sand/60 px-3 py-1 rounded-full items-center gap-1.5 font-mono text-xs text-coffee-dark font-medium">
                    <svg class="w-3.5 h-3.5 text-coffee-rust" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span id="nav-clock">--:--:--</span>
                </div>

                <div class="flex items-center gap-1.5">
                    <a href="javascript:history.back()" class="text-xs font-bold px-3 py-1.5 bg-white hover:bg-coffee-rust hover:text-white border border-coffee-sand rounded-xl shadow-xs transition-all pointer">
                        Quay lại
                    </a>
                </div>

            </div>
        </div>
    </nav>

    <div id="flash-banner-container" class="hidden fixed bottom-6 right-6 z-50 max-w-sm w-full animate-bounce">
        <div id="flash-banner" class="bg-coffee-dark text-white border border-coffee-rust/50 px-4 py-3 rounded-2xl flex items-center gap-2.5 shadow-xl">
            <div class="w-8 h-8 rounded-full bg-coffee-rust flex items-center justify-center shrink-0">
                ☕
            </div>
            <div class="flex-1 text-xs">
                <p id="flash-message" class="font-medium text-coffee-bg">Đã cập nhật trạng thái đồng bộ!</p>
            </div>
        </div>
    </div>

    <main class="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col justify-start">

<div class="max-w-xl w-full mx-auto space-y-6 animate-fade-in my-6">

    <div id="logged-out-container" class="bg-white border border-coffee-sand rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
        
        <div id="login-form-box" class="space-y-6">
            <div class="text-center space-y-1">
                <span class="text-3xl">🔑</span>
                <h2 class="text-2xl font-serif font-bold text-coffee-dark">Hội Viên Đăng Nhập</h2>
                <p class="text-xs text-coffee-milk">Đăng nhập để tích điểm và nhận ưu đãi.</p>
            </div>

            <form onsubmit="handleMemberLogin(event)" class="space-y-4">
                <div class="space-y-1">
                    <label class="text-[10px] font-bold uppercase font-mono tracking-wider text-coffee-milk block">Số điện thoại đăng ký</label>
                    <input type="text" id="login-phone" required placeholder="0909123456" class="w-full text-xs px-4 py-2.5 bg-coffee-light border border-coffee-sand rounded-xl focus:outline-none focus:border-coffee-rust focus:bg-white transition-all font-mono">
                </div>
                <div class="space-y-1">
                    <label class="text-[10px] font-bold uppercase font-mono tracking-wider text-coffee-milk block">Mật khẩu</label>
                    <input type="password" id="login-password" required placeholder="******" class="w-full text-xs px-4 py-2.5 bg-coffee-light border border-coffee-sand rounded-xl focus:outline-none focus:border-coffee-rust focus:bg-white transition-all">
                </div>

                <div class="pt-2">
                    <button type="submit" class="w-full bg-coffee-rust text-white font-bold py-3 rounded-xl text-xs uppercase tracking-wider hover:bg-coffee-rust/95 active:scale-[0.98] transition-colors cursor-pointer text-center shadow-xs">
                        Đăng nhập tài khoản 🔐
                    </button>
                </div>
            </form>

            <div class="text-center border-t border-coffee-sand/60 pt-4">
                <button onclick="toggleForm('register')" class="text-xs font-semibold text-coffee-rust hover:underline bg-transparent border-none cursor-pointer">
                    Chưa có tài khoản? Nhấn đăng ký hội viên ngay 🎟️
                </button>
                <div class="mt-2.5 text-[10px] text-coffee-milk bg-coffee-light/80 p-2 border border-coffee-sand/55 rounded-xl text-left">
                    <p class="font-semibold text-coffee-dark mb-0.5 text-center">💡 Tài khoản hội viên mẫu:</p>
                    <p class="flex justify-between font-mono"><span>• SDT: 0909123456</span> <span>Mật khẩu: 123456</span></p>
                    <p class="flex justify-between font-mono"><span>• SDT: 0901234567</span> <span>Mật khẩu: 123456</span></p>
                </div>
            </div>
        </div>

        <div id="register-form-box" class="hidden space-y-6">
            <div class="text-center space-y-1">
                <span class="text-3xl">🎟️</span>
                <h2 class="text-2xl font-serif font-bold text-coffee-dark">Ghi Danh Hội Viên</h2>
                <p class="text-xs text-coffee-milk">Đăng ký mới để nhận ngay 10 hạt thưởng ban đầu!</p>
            </div>

            <form onsubmit="handleMemberRegister(event)" class="space-y-3.5">
                <div class="space-y-1">
                    <label class="text-[10px] font-bold uppercase font-mono tracking-wider text-coffee-milk block">Họ và tên</label>
                    <input type="text" id="reg-name2" required placeholder="Nguyễn Văn A" class="w-full text-xs px-4 py-2.5 bg-coffee-light border border-coffee-sand rounded-xl focus:outline-none focus:border-coffee-rust">
                </div>
                <div class="space-y-1">
                    <label class="text-[10px] font-bold uppercase font-mono tracking-wider text-coffee-milk block">Số điện thoại</label>
                    <input type="text" id="reg-phone2" required placeholder="09********" class="w-full text-xs px-4 py-2.5 bg-coffee-light border border-coffee-sand rounded-xl focus:outline-none focus:border-coffee-rust font-mono">
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div class="space-y-1">
                        <label class="text-[10px] font-bold uppercase font-mono tracking-wider text-coffee-milk block">Mật khẩu</label>
                        <input type="password" id="reg-password2" required placeholder="******" class="w-full text-xs px-4 py-2.5 bg-coffee-light border border-coffee-sand rounded-xl focus:outline-none focus:border-coffee-rust">
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] font-bold uppercase font-mono tracking-wider text-coffee-milk block">Nhập lại mật khẩu</label>
                        <input type="password" id="reg-confirm2" required placeholder="******" class="w-full text-xs px-4 py-2.5 bg-coffee-light border border-coffee-sand rounded-xl focus:outline-none focus:border-coffee-rust">
                    </div>
                </div>

                <div class="pt-2">
                    <button type="submit" class="w-full bg-coffee-rust text-white font-bold py-3 rounded-xl text-xs uppercase tracking-wider hover:bg-coffee-rust/95 active:scale-[0.98] transition-colors cursor-pointer text-center shadow-xs">
                        Đăng ký ngay tài khoản 🎟️
                    </button>
                </div>
            </form>

            <div class="text-center border-t border-coffee-sand/60 pt-4">
                <button onclick="toggleForm('login')" class="text-xs font-semibold text-coffee-rust hover:underline bg-transparent border-none cursor-pointer">
                    Đã có tài khoản rồi? Trở lại Đăng nhập 🔐
                </button>
            </div>
        </div>

    </div>

    <div id="logged-in-container" class="hidden space-y-6">
        
        <div id="member-card-wrapper" class="bg-gradient-to-br from-coffee-dark to-[#3E2723] text-[#FAF7EE] border border-coffee-rust/35 rounded-3xl p-6 shadow-xl relative overflow-hidden transition-all">
            <div class="absolute -right-8 -bottom-8 w-32 h-32 rounded-full bg-white/5 border border-white/5"></div>
            <div class="absolute right-4 top-4 text-3xl opacity-20">☕</div>

            <div class="flex justify-between items-start border-b border-white/10 pb-4">
                <div>
                    <span class="text-[9px] uppercase tracking-widest font-mono text-coffee-rust font-bold bg-[#FAF7EE] px-2 py-0.5 rounded-md">MEMBER CARD</span>
                    <h4 id="m-name" class="font-serif font-bold italic text-2xl text-white mt-1.5">Nguyễn Văn A</h4>
                    <p id="m-phone" class="text-xs text-coffee-bg/85 font-mono mt-0.5">SĐT: 0392 *** ***</p>
                </div>
                <span id="m-rank" class="text-[9px] uppercase font-mono font-bold tracking-wider px-3 py-1 rounded-full border border-yellow-350 bg-yellow-450/20 text-yellow-300 shadow-2xs">
                    Hội viên Vàng
                </span>
            </div>

            <div class="pt-5 flex justify-between items-center text-xs font-mono">
                <div>
                    <p class="text-[10px] text-coffee-bg/65 uppercase tracking-wider">Hạt Cà Phê tích lũy</p>
                    <p class="text-2xl font-bold text-white mt-0.5 flex items-center gap-1">
                        <span id="m-points">--</span>
                        <span class="text-lg">🫘</span>
                    </p>
                </div>
                <div class="text-right">
                    <p class="text-[10px] text-coffee-bg/65 uppercase tracking-wider">Cộng điểm thanh toán</p>
                    <p class="text-xs text-yellow-300 font-bold mt-1">Tích 5% giá trị hóa đơn (10k = 1 hạt)</p>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <a href="menu.jsp" class="block bg-coffee-rust text-white text-center font-bold py-3 px-4 rounded-xl text-xs uppercase tracking-wider hover:bg-coffee-rust/95 transition-all shadow-xs">
                Gọi món với tài khoản
            </a>
            <a href="order-status.jsp" class="block bg-white text-coffee-dark border border-coffee-sand text-center font-bold py-3 px-4 rounded-xl text-xs uppercase tracking-wider hover:border-coffee-rust transition-all shadow-xs">
                Kiểm tra đơn của tôi
            </a>
        </div>

        <div class="bg-white border border-coffee-sand rounded-3xl p-6 shadow-sm space-y-4">
            <h3 class="text-base font-serif font-bold text-coffee-dark flex items-center gap-1.5">
                <span>🎫</span> Voucher của tôi (Khả dụng gọi nước)
            </h3>
            <p class="text-[11px] text-coffee-milk">Chọn voucher khi thanh toán.</p>
            <div id="owned-vouchers-list" class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            </div>
        </div>

        <div class="bg-white border border-coffee-sand rounded-3xl p-6 shadow-sm space-y-4">
            <div class="border-b border-coffee-sand/70 pb-3">
                <h3 class="text-base font-serif font-bold text-coffee-dark flex items-center gap-1.5">
                    <span>🛍️</span> Đổi quà bằng điểm tích lũy
                </h3>
                <p class="text-xs text-coffee-milk">Dùng điểm để đổi voucher.</p>
            </div>

            <div id="redemption-vouchers-container" class="space-y-3.5">
            </div>
        </div>

        <div class="flex justify-between items-center bg-coffee-light border border-coffee-sand/80 px-5 py-4 rounded-3xl">
            <span class="text-xs text-coffee-milk font-medium">Bảo mật tài khoản hội viên của bạn</span>
            <button onclick="handleMemberLogout()" class="text-xs font-bold px-4 py-2 bg-red-50 hover:bg-red-500 hover:text-white border border-red-200 text-red-600 rounded-xl transition-all cursor-pointer shadow-2xs">
                Đăng xuất tài khoản hội viên ↩
            </button>
        </div>

    </div>

</div>

<script>
    let loggedInMemberPhone = localStorage.getItem('member_phone') || null;
    let availableVoucherCatalog = [];
    let voucherCatalogLoaded = false;
    const fallbackVoucherCatalog = [
        { code: 'CAFE15', name: 'Voucher giảm 15,000đ', discountAmount: 15000, pointCost: 100, active: true },
        { code: 'CAFE30', name: 'Voucher giảm 30,000đ', discountAmount: 30000, pointCost: 200, active: true },
        { code: 'CAFE50', name: 'Voucher giảm 50,000đ', discountAmount: 50000, pointCost: 300, active: true },
        { code: 'CAFE100', name: 'Voucher giảm 100,000đ', discountAmount: 100000, pointCost: 500, active: true }
    ];

    document.addEventListener('DOMContentLoaded', () => {
        updateUIState();
        const params = new URLSearchParams(window.location.search);
        if (!loggedInMemberPhone && (params.get('mode') === 'register' || window.location.hash === '#register')) {
            toggleForm('register');
        }
    });

    function updateUIState() {
        if (loggedInMemberPhone) {
            document.getElementById('logged-out-container').classList.add('hidden');
            document.getElementById('logged-in-container').classList.remove('hidden');
            fetchMemberDetails();
        } else {
            document.getElementById('logged-out-container').classList.remove('hidden');
            document.getElementById('logged-in-container').classList.add('hidden');
        }
    }

    function formatVoucherMoney(value) {
        return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value || 0);
    }

    async function loadVoucherCatalog() {
        if (voucherCatalogLoaded) return;
        try {
            const res = await fetch('api/vouchers', { credentials: 'same-origin' });
            if (!res.ok) throw new Error('Voucher API failed');
            availableVoucherCatalog = await res.json();
            voucherCatalogLoaded = true;
        } catch (error) {
            console.warn('Không tải được voucher từ API, dùng dữ liệu demo.', error);
            availableVoucherCatalog = fallbackVoucherCatalog.slice();
            voucherCatalogLoaded = true;
        }
    }

    function voucherInfo(code) {
        return availableVoucherCatalog.find(v => String(v.code || '').toUpperCase() === String(code || '').toUpperCase());
    }

    function voucherDisplayName(code) {
        const voucher = voucherInfo(code);
        if (!voucher) return 'Voucher không còn áp dụng';
        return voucher.name || ('Voucher giảm ' + formatVoucherMoney(voucher.discountAmount));
    }

    function toggleForm(formType) {
        if (formType === 'register') {
            document.getElementById('login-form-box').classList.add('hidden');
            document.getElementById('register-form-box').classList.remove('hidden');
        } else {
            document.getElementById('login-form-box').classList.remove('hidden');
            document.getElementById('register-form-box').classList.add('hidden');
        }
    }

    async function handleMemberLogin(e) {
        e.preventDefault();
        const phone = document.getElementById('login-phone').value.trim();
        const password = document.getElementById('login-password').value;

        try {
            const res = await fetch('api/members/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ phone, password })
            });

            if (res.ok) {
                const data = await res.json();
                loggedInMemberPhone = data.phone;
                localStorage.setItem('member_phone', data.phone);
                localStorage.setItem('member_name', data.name);
                flashNotify(`🔐 Đăng nhập thành công! Chào bạn \${data.name}`);
                updateUIState();
            } else {
                const err = await res.json();
                alert(err.error || 'Sai số điện thoại hoặc mật khẩu!');
            }
        } catch (error) {
            console.error(error);
            alert('Lỗi khi gửi yêu cầu đăng nhập!');
        }
    }

    async function handleMemberRegister(e) {
        e.preventDefault();
        const name = document.getElementById('reg-name2').value.trim();
        const phone = document.getElementById('reg-phone2').value.trim();
        const password = document.getElementById('reg-password2').value;
        const confirm = document.getElementById('reg-confirm2').value;

        if (password !== confirm) {
            alert('Thất bại: Nhập lại mật khẩu không chính xác!');
            return;
        }

        try {
            const res = await fetch('api/members/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, phone, password })
            });

            if (res.ok) {
                const data = await res.json();
                alert(`🎟️ Ghi danh hội viên thành công! Bạn nhận được 10 hạt thưởng ban đầu.`);
                loggedInMemberPhone = data.phone;
                localStorage.setItem('member_phone', data.phone);
                localStorage.setItem('member_name', data.name);
                updateUIState();
            } else {
                const err = await res.json();
                alert(err.error || 'Ghi danh hội viên thất bại.');
            }
        } catch (error) {
            console.error(error);
            alert('Có lỗi xảy ra trong quá trình đăng ký!');
        }
    }

    async function fetchMemberDetails() {
        if (!loggedInMemberPhone) return;
        try {
            await loadVoucherCatalog();
            const res = await fetch(`api/members/profile?phone=\${loggedInMemberPhone}`);
            if (res.ok) {
                const m = await res.json();
                document.getElementById('m-name').innerText = m.name;
                document.getElementById('m-phone').innerText = 'SĐT: ' + m.phone;
                document.getElementById('m-rank').innerText = 'Hội viên ' + (m.rank === 'Platinum' ? 'Kim Cương' : m.rank === 'Gold' ? 'Vàng' : 'Bạc');
                document.getElementById('m-points').innerText = m.points;
                
                const voucherBox = document.getElementById('owned-vouchers-list');
                voucherBox.innerHTML = '';
                if (!m.vouchers || m.vouchers.length === 0) {
                    voucherBox.innerHTML = `
                        <div class="col-span-1 sm:col-span-2 text-center py-4 bg-coffee-light/50 border border-dashed border-coffee-sand rounded-xl">
                            <p class="text-xs text-coffee-milk italic">Bạn hiện chưa tích lũy Voucher giảm giá nào.</p>
                        </div>
                    `;
                } else {
                    m.vouchers.forEach(vCode => {
                        const voucher = voucherInfo(vCode);
                        const vName = voucherDisplayName(vCode);
                        const activeLabel = voucher && voucher.active !== false ? 'Khả dụng' : 'Tạm tắt';
                        const activeClass = voucher && voucher.active !== false ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-zinc-50 text-zinc-500 border-zinc-200';
                        voucherBox.innerHTML += `
                            <div class="bg-coffee-light border border-coffee-sand/70 p-3.5 rounded-2xl flex justify-between items-center transition-all hover:border-coffee-rust/30">
                                <div>
                                    <p class="text-xs font-extrabold text-coffee-dark font-mono bg-coffee-sand/40 tracking-wider px-2 py-0.5 rounded-md inline-block">\${vCode}</p>
                                    <p class="text-[11px] font-bold text-coffee-rust mt-1">\${vName}</p>
                                </div>
                                <span class="\${activeClass} border text-[9px] uppercase font-bold px-2 py-0.5 rounded-full font-mono">\${activeLabel}</span>
                            </div>
                        `;
                    });
                }

                renderRedemptionList(m.points);
            } else {
                handleMemberLogout();
            }
        } catch (error) {
            console.error(error);
        }
    }

    function renderRedemptionList(points) {
        const list = availableVoucherCatalog.filter(item => item.active !== false);

        const container = document.getElementById('redemption-vouchers-container');
        container.innerHTML = '';

        if (list.length === 0) {
            container.innerHTML = `
                <div class="bg-coffee-light/55 border border-dashed border-coffee-sand rounded-2xl p-4 text-xs text-coffee-milk">
                    Hiện chưa có voucher đang mở đổi.
                </div>
            `;
            return;
        }

        list.forEach(item => {
            const canRedeem = points >= item.pointCost;
            const label = item.name || ('Voucher giảm ' + formatVoucherMoney(item.discountAmount));
            container.innerHTML += `
                <div class="bg-coffee-light/55 border border-coffee-sand/80 rounded-2xl p-4 flex justify-between items-center hover:bg-coffee-light transition-all">
                    <div>
                        <p class="text-xs font-bold text-coffee-dark font-serif">\${label}</p>
                        <p class="text-[11px] text-coffee-milk mt-0.5 font-mono">Chi phí: <span class="text-coffee-rust font-bold">\${item.pointCost}</span> hạt cà phê</p>
                    </div>
                    <button onclick="redeemVoucherCode('\${item.code}')" \${canRedeem ? '' : 'disabled'} class="px-3.5 py-2 rounded-xl text-[10px] uppercase font-bold tracking-wider transition-all shadow-xs \${canRedeem ? 'bg-coffee-rust text-white hover:bg-coffee-rust/95 cursor-pointer active:scale-95' : 'bg-coffee-sand/45 text-coffee-milk/70 cursor-not-allowed'}">
                        Đổi Voucher
                    </button>
                </div>
            `;
        });
    }

    async function redeemVoucherCode(code) {
        try {
            const res = await fetch('api/members/redeem', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ phone: loggedInMemberPhone, code })
            });

            if (res.ok) {
                flashNotify(`🎟️ Đổi thành công mã Voucher: \${code}!`);
                fetchMemberDetails();
            } else {
                const err = await res.json();
                alert(err.error || 'Không thể đổi Voucher này.');
            }
        } catch (error) {
            console.error(error);
        }
    }

    function handleMemberLogout() {
        localStorage.removeItem('member_phone');
        localStorage.removeItem('member_name');
        loggedInMemberPhone = null;
        flashNotify('Đã đăng xuất tài khoản thành viên thành công!');
        updateUIState();
    }
</script>

    </main>

    <footer class="mt-auto py-6 border-t border-coffee-sand/70 bg-white/70 backdrop-blur-xs text-xs text-coffee-milk">
        <div class="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p class="font-serif italic font-bold text-sm text-coffee-dark">
                nhà cà phê © 2026
            </p>
            <div class="flex gap-4 font-mono text-[10px] tracking-wider">
                <span>VER: 3.0.1</span>
            </div>
        </div>
    </footer>

    <script>
        if (document.getElementById('nav-clock')) {
            setInterval(() => {
                document.getElementById('nav-clock').innerText = new Date().toLocaleTimeString('vi-VN');
            }, 1000);
        }

        function flashNotify(msg) {
            const holder = document.getElementById('flash-banner-container');
            const target = document.getElementById('flash-message');
            if (holder && target) {
                target.innerText = msg;
                holder.classList.remove('hidden');
                setTimeout(() => {
                    holder.classList.add('hidden');
                }, 4000);
            }
        }
    </script>
</body>
</html>
