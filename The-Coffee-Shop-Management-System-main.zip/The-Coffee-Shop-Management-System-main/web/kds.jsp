<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nhà cà phê. — quản lý quán</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        coffee: {
                            bg: '#FAF8F3',       
                            dark: '#2B1B17',     
                            rust: '#A04423',     
                            sand: '#E5DEC9',     
                            light: '#FAF7EE',    
                            milk: '#8E7D6F'      
                        }
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #FAF8F3;
            color: #2B1B17;
        }
        .font-serif {
            font-family: 'Playfair Display', serif;
        }
        .font-mono {
            font-family: 'JetBrains Mono', monospace;
        }
        
        .dot-grid-bg {
            background-color: #FAF8F3;
            background-image: radial-gradient(#d3cbb6 1.2px, transparent 1.2px);
            background-size: 24px 24px;
        }
        
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: rgba(43, 27, 23, 0.05);
            border-radius: 99px;
        }
        ::-webkit-scrollbar-thumb {
            background: rgba(160, 68, 35, 0.3);
            border-radius: 99px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: rgba(160, 68, 35, 0.5);
            border-radius: 99px;
        }
    </style>
    <script>
        (function() {
            var role = localStorage.getItem('auth_role') || '';
            var user = localStorage.getItem('auth_user') || '';
            var path = window.location.pathname;
            var page = path.substring(path.lastIndexOf('/') + 1) || 'index.html';

            var customerPages = ['menu.jsp', 'order-status.jsp', 'member.jsp'];
            var waiterPages = ['waitstation.jsp', 'staff-orders.jsp', 'table-qr.jsp', 'order-summary.jsp'];
            var baristaPages = ['kds.jsp'];
            var managerPages = ['dashboard.jsp', 'reports.jsp', 'staff-management.jsp', 'inventory.jsp'];

            if (role && waiterPages.indexOf(page) !== -1 && role !== 'waiter' && role !== 'manager') {
                try { alert('Cảnh báo bảo mật: Bạn không có quyền truy cập khu vực Phục vụ / Wait station!'); } catch(e) { console.warn(e); }
                window.location.href = 'login.jsp';
                return;
            }
            if (role && baristaPages.indexOf(page) !== -1 && role !== 'barista' && role !== 'manager') {
                try { alert('Cảnh báo bảo mật: Bạn không có quyền truy cập khu vực Quầy pha chế (KDS)!'); } catch(e) { console.warn(e); }
                window.location.href = 'login.jsp';
                return;
            }
            if (role && managerPages.indexOf(page) !== -1 && role !== 'manager') {
                try { alert('Cảnh báo bảo mật: Bạn không có quyền truy cập khu vực Bảng điều khiển Quản lý!'); } catch(e) { console.warn(e); }
                window.location.href = 'login.jsp';
                return;
            }

            document.addEventListener("DOMContentLoaded", function() {
                var navContainer = document.querySelector('nav div.hidden.lg\\:flex');
                if (!navContainer) return;

                var navHtml = '';
                if (customerPages.indexOf(page) !== -1 || page === 'index.html' || page === 'login.jsp' || page === 'pin-login.jsp') {
                    if (!role) {
                        navHtml = 
                            '<a href="index.html" class="hover:text-coffee-rust transition-colors ' + (page === 'index.html' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Trang chủ</a>' +
                            '<a href="menu.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'menu.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + ' font-semibold">Khách gọi món</a>' +
                            '<a href="order-status.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'order-status.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Kiểm tra đơn nước</a>' +
                            '<a href="member.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'member.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Khách thành viên</a>';
                    } else if (role === 'waiter') {
                        navHtml = 
                            '<a href="index.html" class="hover:text-coffee-rust transition-colors">Trang chủ</a>' +
                            '<a href="waitstation.jsp" class="hover:text-coffee-rust transition-colors font-semibold">Wait station</a>' +
                            '<a href="staff-orders.jsp" class="hover:text-coffee-rust transition-colors">Danh sách order</a>' +
                            '<a href="table-qr.jsp" class="hover:text-coffee-rust transition-colors">In mã QR bàn</a>';
                    } else if (role === 'barista') {
                        navHtml = 
                            '<a href="index.html" class="hover:text-coffee-rust transition-colors">Trang chủ</a>' +
                            '<a href="kds.jsp" class="hover:text-coffee-rust transition-colors font-semibold">KDS pha chế</a>';
                    } else if (role === 'manager') {
                        navHtml = 
                            '<a href="index.html" class="hover:text-coffee-rust transition-colors">Trang chủ</a>' +
                            '<a href="dashboard.jsp" class="hover:text-coffee-rust transition-colors">Dashboard</a>' +
                            '<a href="reports.jsp" class="hover:text-coffee-rust transition-colors">Doanh số</a>' +
                            '<a href="staff-management.jsp" class="hover:text-coffee-rust transition-colors">Nhân sự</a>' +
                            '<a href="inventory.jsp" class="hover:text-coffee-rust transition-colors">Kho hàng</a>' +
                           '<div class="relative group">' +
                               '<button class="bg-coffee-light hover:bg-coffee-sand/30 text-coffee-dark border border-coffee-sand px-3 py-1 rounded-lg flex items-center gap-1 cursor-pointer">' +
                                   '<span>Thao tác trực</span>' +
                                   '<svg class="w-3 h-3 text-coffee-rust" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>' +
                               '</button>' +
                               '<div class="absolute left-0 mt-1 w-52 bg-white border border-coffee-sand rounded-xl shadow-lg py-1.5 hidden group-hover:block z-50">' +
                                '<a href="inventory.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Kho nguyên liệu</a>' +
                                
                                    '<a href="inventory.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Kho nguyên liệu</a>' +
                                    '<a href="waitstation.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Wait station</a>' +
                                   '<a href="kds.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">KDS pha chế</a>' +
                                   '<a href="staff-orders.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Danh sách order</a>' +
                                   '<a href="table-qr.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">In mã QR bàn</a>' +
                                   '<a href="menu.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Giao diện khách</a>' +
                               '</div>' +
                           '</div>';
                    }
                } else if (role === 'waiter' || waiterPages.indexOf(page) !== -1) {
                    navHtml = 
                        '<a href="index.html" class="hover:text-coffee-rust transition-colors ' + (page === 'index.html' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Trang chủ</a>' +
                        '<a href="waitstation.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'waitstation.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + ' font-semibold">Wait station</a>' +
                        '<a href="staff-orders.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'staff-orders.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Danh sách order</a>' +
                        '<a href="table-qr.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'table-qr.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">In mã QR bàn</a>';
                } else if (role === 'barista' || baristaPages.indexOf(page) !== -1) {
                    navHtml = 
                        '<a href="index.html" class="hover:text-coffee-rust transition-colors ' + (page === 'index.html' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Trang chủ</a>' +
                        '<a href="kds.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'kds.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + ' font-semibold">KDS pha chế</a>';
                } else if (role === 'manager' || managerPages.indexOf(page) !== -1) {
                    navHtml = 
                        '<a href="index.html" class="hover:text-coffee-rust transition-colors ' + (page === 'index.html' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Trang chủ</a>' +
                        '<a href="dashboard.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'dashboard.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + ' font-semibold">Dashboard</a>' +
                        '<a href="reports.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'reports.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Doanh số</a>' +
                        '<a href="staff-management.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'staff-management.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Nhân sự</a>' +
                        '<a href="inventory.jsp" class="hover:text-coffee-rust transition-colors ' + (page === 'inventory.jsp' ? 'text-coffee-dark font-bold' : 'text-coffee-milk') + '">Kho hàng</a>' +
                        '<div class="relative group">' +
                            '<button class="bg-coffee-light hover:bg-coffee-sand/30 text-coffee-dark border border-coffee-sand px-3 py-1 rounded-lg flex items-center gap-1 cursor-pointer">' +
                                '<span>Thao tác trực</span>' +
                                '<svg class="w-3 h-3 text-coffee-rust" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>' +
                            '</button>' +
                            '<div class="absolute left-0 mt-1 w-52 bg-white border border-coffee-sand rounded-xl shadow-lg py-1.5 hidden group-hover:block z-50">' +
                                '<a href="inventory.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Kho nguyên liệu</a>' +
                                
                                    '<a href="inventory.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Kho nguyên liệu</a>' +
                                    '<a href="waitstation.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">Wait station</a>' +
                                '<a href="kds.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors font-semibold">KDS pha chế</a>' +
                                '<a href="staff-orders.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Danh sách order</a>' +
                                '<a href="table-qr.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">In mã QR bàn</a>' +
                                '<a href="menu.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Giao diện khách</a>' +
                            '</div>' +
                        '</div>';
                }
                navContainer.innerHTML = navHtml;

                var rightNavArea = document.querySelector('nav div.flex.items-center.gap-3 div.flex.items-center.gap-1\\.5') || document.querySelector('nav div.flex.items-center.gap-3');
                if (rightNavArea && role) {
                    var roleBadge = '';
                    if (role === 'manager') roleBadge = 'Quản lý';
                    else if (role === 'waiter') roleBadge = 'Phục vụ';
                    else if (role === 'barista') roleBadge = 'Pha chế';

                    var badgeHtml = 
                        '<div class="flex items-center gap-2">' +
                            '<div class="bg-coffee-dark text-coffee-bg border border-coffee-rust/30 px-3.5 py-1.5 rounded-xl text-[10px] uppercase font-bold font-mono tracking-wide flex items-center gap-1.5 shadow-xs">' +
                                '<span class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping"></span>' +
                                '<span>' + roleBadge + ': ' + user + '</span>' +
                            '</div>' +
                            '<button onclick="handleLocalLogout()" class="text-xs font-bold px-2 py-1.5 bg-red-50 hover:bg-red-500 hover:text-white border border-red-200 text-red-600 rounded-xl shadow-xs transition-all cursor-pointer">' +
                                'Đăng xuất' +
                            '</button>' +
                        '</div>';

                    var backBtnChild = rightNavArea.querySelector('a[href="index.html"]');
                    if (backBtnChild) {
                        backBtnChild.parentElement.innerHTML = badgeHtml;
                    } else {
                        var existingLogoutBtn = rightNavArea.querySelector('button[onclick="handleLocalLogout()"]');
                        if (!existingLogoutBtn) {
                            var badgeDiv = document.createElement('div');
                            badgeDiv.className = 'flex items-center gap-1.5 ml-2';
                            badgeDiv.innerHTML = badgeHtml;
                            rightNavArea.appendChild(badgeDiv);
                        }
                    }
                }
            });
        })();

        function handleLocalLogout() {
            localStorage.removeItem('auth_role');
            localStorage.removeItem('auth_user');
            alert('Đã đăng xuất tài khoản làm việc POS! Chuyển hướng về cổng portal.');
            window.location.href = 'index.html';
        }
    </script>
    <link rel="stylesheet" href="assets/css/pro-ui.css">
    <script defer src="assets/js/ui-polish.js"></script>
</head>
<body class="min-h-screen flex flex-col dot-grid-bg relative selection:bg-coffee-rust/20 selection:text-coffee-rust">

    <nav class="border-b border-coffee-sand/70 bg-coffee-bg/90 backdrop-blur sticky top-0 z-40 px-6 py-4 transition-all">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            
            <a href="index.html" class="flex items-center gap-2 group">
                <span class="text-2xl font-serif font-extrabold tracking-tight text-coffee-dark select-none">
                    nhà cà phê<span class="text-coffee-rust">.</span>
                </span>
            </a>

            <div class="hidden lg:flex items-center gap-4 text-xs font-medium">
                <a href="index.html" class="hover:text-coffee-rust transition-colors text-coffee-milk">Trang chủ</a>
                <a href="menu.jsp" class="hover:text-coffee-rust transition-colors text-coffee-dark font-bold">Khách gọi món</a>
                <a href="waitstation.jsp" class="hover:text-coffee-rust transition-colors text-coffee-milk">Wait station</a>
                <a href="kds.jsp" class="hover:text-coffee-rust transition-colors text-coffee-milk">KDS pha chế</a>
                
                <div class="relative group">
                    <button class="bg-coffee-light hover:bg-coffee-sand/30 text-coffee-dark border border-coffee-sand px-3 py-1 rounded-lg flex items-center gap-1 cursor-pointer">
                        <span>Chức năng khác</span>
                        <svg class="w-3 h-3 text-coffee-rust" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
                    </button>
                    <div class="absolute left-0 mt-1 w-52 bg-white border border-coffee-sand rounded-xl shadow-lg py-1.5 hidden group-hover:block z-50">
                        <a href="dashboard.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Dashboard</a>
                        <a href="reports.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Báo cáo doanh số</a>
                        <a href="staff-orders.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Danh sách order</a>
                        <a href="staff-management.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Quản lý nhân sự</a>
                        <a href="table-qr.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">In mã QR bàn</a>
                        <a href="member.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Khách thành viên</a>
                        <a href="order-status.jsp" class="block px-4 py-2 hover:bg-coffee-light text-coffee-dark hover:text-coffee-rust transition-colors">Kiểm tra đơn nước</a>
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-3">
                
                <div id="connection-status">
                    <div class="bg-amber-50 text-amber-800 border border-amber-200/50 px-3 py-1 rounded-full text-xs flex items-center gap-1.5 font-medium">
                        <span class="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse"></span>
                        <span>Đang kết nối...</span>
                    </div>
                </div>

                <div class="hidden md:flex bg-coffee-light border border-coffee-sand/60 px-3 py-1 rounded-full items-center gap-1.5 font-mono text-xs text-coffee-dark font-medium">
                    <svg class="w-3.5 h-3.5 text-coffee-rust" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span id="nav-clock">--:--:--</span>
                </div>

                <div class="flex items-center gap-1.5">
                    <a href="javascript:history.back()" class="text-xs font-bold px-3 py-1.5 bg-white hover:bg-coffee-rust hover:text-white border border-coffee-sand rounded-xl shadow-xs transition-all pointer">
                        Quay lại
                    </a>
                </div>

            </div>
        </div>
    </nav>

    <div id="flash-banner-container" class="hidden fixed bottom-6 right-6 z-50 max-w-sm w-full animate-bounce">
        <div id="flash-banner" class="bg-coffee-dark text-white border border-coffee-rust/50 px-4 py-3 rounded-2xl flex items-center gap-2.5 shadow-xl">
            <div class="w-8 h-8 rounded-full bg-coffee-rust flex items-center justify-center shrink-0">
                ☕
            </div>
            <div class="flex-1 text-xs">
                <p id="flash-message" class="font-medium text-coffee-bg">Đã cập nhật trạng thái đồng bộ!</p>
            </div>
        </div>
    </div>

    <main class="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col justify-start">

<div class="space-y-6">
    <div class="bg-white border border-coffee-sand/70 p-5 rounded-3xl shadow-xs flex justify-between items-center">
        <div>
            <h2 class="text-xl font-serif italic font-bold text-coffee-dark flex items-center gap-2">
                <span>👩‍🍳</span> Màn hình điều phối chế biến (Kitchen Display KDS)
            </h2>
            <p class="text-xs text-coffee-milk font-medium">Đơn pha chế đang chờ.</p>
        </div>
        <div class="bg-coffee-rust text-white font-mono text-[11px] font-bold px-3 py-1.5 rounded-full uppercase tracking-wider">
            Quầy bar chính
        </div>
    </div>

    <div id="kds-empty-msg" class="hidden bg-[#FAF7EE] rounded-3xl border border-coffee-sand p-16 text-center text-coffee-milk space-y-3 max-w-md mx-auto shadow-sm">
        <span class="text-5xl">😴</span>
        <p class="font-serif italic font-bold text-coffee-dark text-lg">Hiện không có đơn nào cần làm!</p>
        <p class="text-xs">Quầy bar đang trống.</p>
    </div>

    <div id="kds-tickets-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    </div>
</div>

<script>
    let menu = [];
    let tables = [];
    let orders = [];
    let socket = null;

    function formatVND(amt) {
        return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amt);
    }

    async function fetchStateCore() {
        try {
            const [rMenu, rTables, rOrders] = await Promise.all([
                fetch('api/menu'),
                fetch('api/tables'),
                fetch('api/orders')
            ]);
            if (rMenu.ok) menu = await rMenu.json();
            if (rTables.ok) tables = await rTables.json();
            if (rOrders.ok) orders = await rOrders.json();

            drawKDS();
        } catch (err) {
            console.error('KDS data error', err);
        }
    }

    function playAlertTone() {
        try {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;
            const context = new AudioCtx();
            const synth = (freq, delay, length) => {
                setTimeout(() => {
                    const osc = context.createOscillator();
                    const filter = context.createGain();
                    osc.connect(filter);
                    filter.connect(context.destination);
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(freq, context.currentTime);
                    filter.gain.setValueAtTime(0.12, context.currentTime);
                    filter.gain.exponentialRampToValueAtTime(0.001, context.currentTime + length);
                    osc.start();
                    osc.stop(context.currentTime + length);
                }, delay);
            };
            synth(523.25, 0, 0.3); // C5
            synth(659.25, 120, 0.35); // E5
        } catch (e) {
            console.warn('Audio interaction bypassed.', e);
        }
    }

    function setupWebSocket() {
        const sockProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const endpoint = `\${sockProtocol}//\${window.location.host}\${window.location.pathname.substring(0, window.location.pathname.lastIndexOf("/"))}/ws`;
        socket = new WebSocket(endpoint);

        socket.onopen = () => {
            setWsIndicator('connected');
            fetchStateCore();
        };

        socket.onmessage = () => {
            fetchStateCore();
            playAlertTone();
            flashNotify('🔔 Nhận order pha chế mới từ quầy dọn món!');
        };

        socket.onclose = () => {
            setWsIndicator('disconnected');
            setTimeout(setupWebSocket, 4000);
        };
    }

    function setWsIndicator(stat) {
        const indicator = document.getElementById('connection-status');
        if (!indicator) return;
        if (stat === 'connected') {
            indicator.innerHTML = `
                <div class="bg-emerald-50 text-emerald-800 border border-emerald-250/60 px-3 py-1 rounded-full text-xs flex items-center gap-1.5 font-bold animate-pulse">
                    <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                    <span>Đồng bộ pha chế trực tiếp</span>
                </div>
            `;
        } else {
            indicator.innerHTML = `
                <div class="bg-red-50 text-red-800 border border-red-200/60 px-3 py-1 rounded-full text-xs flex items-center gap-1.5 font-bold">
                    <span class="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping"></span>
                    <span>Mất kết nối KDS</span>
                </div>
            `;
        }
    }

    function drawKDS() {
        const grid = document.getElementById('kds-tickets-grid');
        const emptyLabel = document.getElementById('kds-empty-msg');

        if (!grid) return;
        grid.innerHTML = '';

        const tickets = orders.filter(o => o.status !== 'Served');

        if (tickets.length === 0) {
            emptyLabel.classList.remove('hidden');
            grid.classList.add('hidden');
            return;
        }

        emptyLabel.classList.add('hidden');
        grid.classList.remove('hidden');

        tickets.forEach(o => {
            let cardBadge = 'bg-coffee-light border-coffee-sand text-coffee-milk';
            if (o.status === 'Preparing') cardBadge = 'bg-amber-100 border-amber-200 text-amber-805';
            else if (o.status === 'Ready') cardBadge = 'bg-emerald-100 border-emerald-250 text-emerald-800 animate-pulse';

            const ageMin = Math.floor((new Date() - new Date(o.createdAt)) / 60000);
            const ageText = ageMin <= 0 ? 'Mới chế' : `\${ageMin} phút trước`;

            const completeCount = o.items.filter(it => it.status === 'Ready' || it.status === 'Served').length;
            const ratio = Math.round((completeCount / o.items.length) * 100);

            let itemsRows = '';
            o.items.forEach(it => {
                let rowClass = 'text-coffee-dark';
                let stBadge = 'bg-coffee-light text-coffee-milk border-coffee-sand/70';
                let label = 'Chờ chế biến';
                let nextStatus = 'Preparing';

                if (it.status === 'Preparing') {
                    rowClass = 'text-amber-800 font-bold';
                    stBadge = 'bg-amber-100 text-amber-800 border-amber-250';
                    label = 'Đang pha';
                    nextStatus = 'Ready';
                } else if (it.status === 'Ready') {
                    rowClass = 'text-emerald-800 line-through opacity-75';
                    stBadge = 'bg-emerald-100 text-emerald-800 border-emerald-200';
                    label = 'Đã sẵn sàng';
                    nextStatus = 'Served';
                } else if (it.status === 'Served') {
                    rowClass = 'opacity-35 line-through';
                    stBadge = 'bg-coffee-rust/10 text-coffee-rust border-transparent';
                    label = 'Đã bưng';
                    nextStatus = 'Served';
                }

                const actionHandler = it.status !== 'Served' ? `onclick="toggleBaristaItem('\${o.id}', '\${it.id}', '\${nextStatus}')"` : '';

                itemsRows += `
                    <div \${actionHandler} class="flex items-start justify-between p-2.5 rounded-xl transition-all border border-transparent hover:border-coffee-sand/40 \${it.status !== 'Served' ? 'hover:bg-coffee-light/40 cursor-pointer' : ''}">
                        <div class="space-y-0.5 pr-2">
                            <p class="text-xs \${rowClass}">
                                \${it.name} <span class="font-mono text-xs opacity-80">x\${it.quantity}</span>
                            </p>
                            <p class="text-[9.5px] text-coffee-milk">Size \${it.customization ? it.customization.size : 'M'} \u2022 Ngọt:\${it.customization ? it.customization.sugar : '100%'} \u2022 Đá:\${it.customization ? it.customization.ice : '100%'}</p>
                            \${it.notes ? `<p class="text-[9px] bg-amber-50 text-amber-800 rounded px-1.5 py-0.5 inline-block block italic mt-1 font-medium">"\${it.notes}"</p>` : ''}
                        </div>
                        <span class="text-[9px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border shrink-0 \${stBadge}">
                            \${label}
                        </span>
                    </div>
                `;
            });

            grid.innerHTML += `
                <div class="bg-white border border-coffee-sand rounded-3xl p-5 shadow-xs flex flex-col justify-between hover:shadow-xs transition-all gap-4">
                    <div class="space-y-3.5">
                        <div class="flex justify-between items-start border-b border-coffee-light pb-2">
                            <div>
                                <span class="text-[10px] font-mono font-bold text-coffee-milk uppercase bg-coffee-light px-2 py-0.5 rounded border">BÀN: \${o.tableName}</span>
                                <h4 class="font-serif font-bold italic text-base mt-1 text-coffee-dark">HÓA ĐƠN #\${o.orderNumber}</h4>
                            </div>
                            <div class="text-right">
                                <span class="text-[9px] font-mono uppercase tracking-wider font-bold px-2 py-0.5 rounded-full border \${cardBadge}">
                                    \${o.status === 'Pending' ? 'ĐỢI PHÊ' : o.status === 'Preparing' ? 'ĐANG PHA' : 'ĐỒ XONG'}
                                </span>
                                <p class="text-[10px] text-coffee-milk font-mono mt-1">\${ageText}</p>
                            </div>
                        </div>

                        <div class="space-y-1">
                            <div class="flex justify-between items-center text-[10px] text-coffee-milk font-mono font-bold">
                                <span>Tiến độ múc:</span>
                                <span>\${ratio}%</span>
                            </div>
                            <div class="w-full bg-coffee-light h-1.5 rounded-full overflow-hidden border border-coffee-sand/30">
                                <div class="bg-coffee-rust h-full rounded-full transition-all duration-300" style="width: \${ratio}%"></div>
                            </div>
                        </div>

                        <div class="space-y-1 shadow-2xs divide-y divide-coffee-sand/20">
                            \${itemsRows}
                        </div>

                        \${o.notes ? `
                            <div class="bg-amber-50/50 border border-amber-150 rounded-xl p-2.5 text-[10px] text-amber-900 leading-normal font-medium">
                                Ghi chú bếp: "\${o.notes}"
                            </div>
                        ` : ''}
                    </div>

                    <div class="pt-3 border-t border-coffee-sand/45 mt-1">
                        <button onclick="postTicketComplete('\${o.id}')" class="w-full bg-coffee-light text-coffee-rust border border-coffee-sand hover:bg-coffee-rust hover:text-white transition-all py-2 rounded-xl text-xs font-bold font-mono tracking-wider cursor-pointer">
                            HOÀN TẤT LÊN ĐỒ 🏁
                        </button>
                    </div>
                </div>
            `;
        });
    }

    async function toggleBaristaItem(orderId, itemId, nextStatus) {
        try {
            await fetch(`api/orders/\${orderId}/items/\${itemId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: nextStatus })
            });
        } catch (err) {
            console.error('KDS action error', err);
        }
    }

    async function postTicketComplete(orderId) {
        try {
            await fetch(`api/orders/\${orderId}/status`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'Served' })
            });
        } catch (err) {
            console.error('KDS bulk action error', err);
        }
    }

    setupWebSocket();
</script>

    </main>

    <footer class="mt-auto py-6 border-t border-coffee-sand/70 bg-white/70 backdrop-blur-xs text-xs text-coffee-milk">
        <div class="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p class="font-serif italic font-bold text-sm text-coffee-dark">
                nhà cà phê © 2026
            </p>
            <div class="flex gap-4 font-mono text-[10px] tracking-wider">
                <span>VER: 3.0.1</span>
            </div>
        </div>
    </footer>

    <script>
        if (document.getElementById('nav-clock')) {
            setInterval(() => {
                document.getElementById('nav-clock').innerText = new Date().toLocaleTimeString('vi-VN');
            }, 1000);
        }

        function flashNotify(msg) {
            const holder = document.getElementById('flash-banner-container');
            const target = document.getElementById('flash-message');
            if (holder && target) {
                target.innerText = msg;
                holder.classList.remove('hidden');
                setTimeout(() => {
                    holder.classList.add('hidden');
                }, 4000);
            }
        }
    </script>
</body>
</html>
